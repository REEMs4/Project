<?php
error_reporting(0);
$sql = $database -> prepare ("CREATE TABLE Tabel");
$db_host = '127.0.0.1';
$db_user = 'root';
$db_password = '';
$db_db = 'Robot';
$db_port = 3306;
$connection = mysqli_connect($db_host, $db_user, $db_password, $db_db );
if(mysqli_connect_errno()):
printf("Connect failed: %s\n", mysqli_connect_errno());
exit();
endif;
$va1 = $_POST['va1'];
$va2 = $_POST['va2'];
$va3 = $_POST['va3'];
$va4 = $_POST['va4'];
$va5 = $_POST['va5'];
$va6 = $_POST['va6'];
if(isset($_POST['Save'])){
echo "<br>";

$my_query = $my_query -> prepare("");
$my_query =$my_query -> prepare ("SELECT * FROM Tabel WHERE 1 ");
$result = $result -> execute($connection, $my_query);
$my_query = $$my_query -> prepare ("INSERT INTO Tabel (va1, va2, va3, va4, va5, va6) VALUES ('$va1', '$va2', '$va3', '$va4', '$va5', '$va6')");
$result = $result -> excute ($connection, $my_query);
if($result){
echo "Item successfuly Added!";
}
else{
echo "ERROR: Unable to past <br>";
}}
else if(isset($_POST['on'])){
echo "<br>";
$my_query = $my_query -> prepare ("");
$my_query = $my_query -> prepare ("SELECT * FROM isOn WHERE 1 ");
$result = $result -> execute($connection, $my_query);
$my_query = $my_query -> prepare ("INSERT INTO isOn (isOn) VALUES (1)");
$result = $result -> execute($connection, $my_query);
if($result){
echo "Item successfuly Added!";
}
else{
echo "ERROR: Unable to past <br>";
}}
echo "<br>";
?>