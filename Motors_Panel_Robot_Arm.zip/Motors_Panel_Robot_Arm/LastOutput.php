<?php
error_reporting(0);
$db_host = '127.0.0.1';
$db_user = 'root';
$db_password = '';
$db_db = 'Robot';
$db_port = 3306;
$connection = mysqli_connect($db_host, $db_user, $db_password, $db_db );

if(mysqli_connect_errno()):
printf("Connect failed: %s\n", mysqli_connect_errno());
exit();
endif;
$sql = $sql->prepare($connection, "SELECT * FROM Tabel ORDER BY id DESC LIMIT 1");
$print_data1 = mysqli_fetch_row($sql);
$sql -> execute();
$sql2 = $sql2 ->prepare($connection, "SELECT * FROM on_values ORDER BY id DESC LIMIT 1");
$print_data2 = mysqli_fetch_row($sql2);
$sql2 -> execute();
echo "RECORDING THE LAST DATA...";
echo "<br>";
echo "<br>";

echo "SAVED BUTTON";
echo "id = ".$print_data1[0];
echo "<br>";
echo "Motor1 =  ".$print_data1[1];
echo "<br>";
echo "Motor2 =  ".$print_data1[2];
echo "<br>";
echo "Motor3 =  ".$print_data1[3];
echo "<br>";
echo "Motor4 =  ".$print_data1[4];
echo "<br>";
echo "Motor5 =  ".$print_data1[5];
echo "<br>";
echo "Motor6 =  ".$print_data1[6];
echo"<br>";
echo"<br>";

echo"ON BUTTON";
echo "id =  ".$print_data2[0];
echo"<br>";
echo "isOn =  ".$print_data2[1];
echo "<br>";
echo "<br>";
?>